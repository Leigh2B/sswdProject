// Connect to Ms SQL databse and make a connection pool available
let sql = require('mssql');

// configure the package used to manage configuration options
const config = require('config');

// setting up the database connection
// the config is used to read values from the connection section of /config/defualt.jso
let dbConnPoolPromise = new sql.ConnectionPool(config.get('connection'))
        .connect()
        .then(pool => {
        console.log('Connected to MSSQL')
        return pool
        })
        .catch(err => console.log('Database connection failed - error: ', err))

// now we want to export the sql and the connection pool objects
module.exports = {
    sql, dbConnPoolPromise
};