// adding the dependencies
const router  = require('express').Router();

// inputting the validation package
let validator = require('validator');

// require the database connection
const { sql, dbConnPoolPromise } = require('../database/db.js');

// Define SQL statements here for use in function below
// These are parameterised queries note @named parameters.
// Input parameters are parsed and set before queries are executed

// for json path - Tell MS SQL to return results as JSON
const SQL_SELECT_ALL = 'SELECT * FROM dbo.Product for json path;';

// without_array_wrapper - use for single result
const SQL_SELECT_BY_ID = 'SELECT * FROM dbo.Product WHERE ProductId = @id for json path, without_array_wrapper;';

// Second statement (Select...) returns inserted record identified by ProductId = SCOPE_IDENTITY()
const SQL_INSERT = 'INSERT INTO dbo.Product (CategoryId, ProductName, ProductDescription, ProductStock, ProductPrice) VALUES (@categoryId, @productName, @productDescription, @ProductStock, @ProductPrice); SELECT * from dbo.Product WHERE ProductId = SCOPE_IDENTITY();';
const SQL_UPDATE = 'UPDATE dbo.Product SET CategoryId = @categoryId, ProductName = @productName, ProductDescription = @productDescription, ProductStock = @ProductStock, ProductPrice = @ProductPrice WHERE ProductId = @id; SELECT * FROM dbo.Product WHERE ProductId = @id;';
const SQL_DELETE = 'DELETE FROM dbo.Product WHERE ProductId = @id;'

// GET listing of all the products
// address http://server:port/product
// returns json

router.get('/',async (req, res) => {
    try {
        const pool = await dbConnPoolPromise // await the database connection
        const result = await pool.request()
            // executing the query
            .query(SQL_SELECT_ALL);

        // sending the HTTP response
        // JSON data from ms sql is contained in the first element of the recordset
        res.json(result.recordset[0]);

        // catch and send any errors
    } catch (err){
        res.status(500);
        res.send(err.message)
    }
});

// exporting this module ( the last line of product.js)
module.exports = router;


// now we want to return a single product from the data
// id is passed as a parameter via url
// address http://server:port/product/id
// returns json
router.get('/:id', async (req, res) => {

    // read the value of the id parameter from the request url
    const productId = req.params.id;

    // now we want to validate input - important as a bad input could crash the server or lead to an attack
    // if validator fails return an error message
    if(!validator.isNumeric(productId, {no_symbols: true})) {
        res.json({"error": "invalid id parameter"});
        return false;
    }

    // if validation passed ececute the query and return the results
    // returns a single product with the matching id
    try {
        // get a db connection and execute the sql
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // set the name parameter(s) in query
            .input('id', sql.Int, productId)
            // execute query
            .query(SQL_SELECT_BY_ID)

        // send response with JSON result
        res.json(result.recordset)
        
    } catch(err) {
        res.status(500)
        res.send(err.message)
    }
});
// POST - Insert a new product.

// This async function sends a HTTP post request

router.post('/', async (req, res) => {

    // Validate - this string, inially empty, will store any errors
    
    let errors = "";
    
    // Make sure that category id is just a number - note that values are read from request body
    
    const categoryId = req.body.categoryId;
    
    if (!validator.isNumeric(categoryId, {no_symbols: true})) {
    
    errors+= "invalid category id; ";
    
    }
    
    // Escape text and potentially bad characters
    
    const productName = validator.escape(req.body.productName);
    
    if (productName === "") {
    
    errors+= "invalid productName; ";
    
    }
    
    const productDescription = validator.escape(req.body.productDescription);
    
    if (productDescription === "") {
    
    errors+= "invalid productDescription; ";
    
    }
    
    // Make sure that category id is just a number
    
    const productStock = req.body.productStock;
    
    if (!validator.isNumeric(productStock, {no_symbols: true})) {
    
    errors+= "invalid productStock; ";
    
    }
    
    // Validate currency
    
    const productPrice = req.body.productPrice;
    
    if (!validator.isCurrency(productPrice, {allow_negatives: false})) {
    
    errors+= "invalid productPrice; ";
    
    }
    
    // If errors send details in response
    
    if (errors != "") {
    
    // return http response with errors if validation failed
    
    res.json({ "error": errors });
    
    return false;
    
    }
    
    // If no errors, insert
    
    try {
    
    // Get a DB connection and execute SQL
    
    const pool = await dbConnPoolPromise
    
    const result = await pool.request()
    
    // set name parameter(s) in query
    
    .input('categoryId', sql.Int, categoryId)
    .input('productName', sql.NVarChar, productName)
    .input('productDescription', sql.NVarChar, productDescription)
    .input('productStock', sql.Int, productStock)
    .input('productPrice', sql.Decimal, productPrice)
    
    // Execute Query
    
    .query(SQL_INSERT);
    
    // If successful, return inserted product via HTTP
    
    res.json(result.recordset[0]);
    
    } catch (err) {
    
    res.status(500)
    
    res.send(err.message)
    
    }
    
    });

// put - updating a new product.

// This async function sends a HTTP post request

router.put('/product', async (req, res) => {

    // Validate - this string, inially empty, will store any errors
    
    let errors = "";
    
    // Make sure that category id is just a number - note that values are read from request body
    const productId = req.body.productId;
    const categoryId = req.body.categoryId;
    
    if (!validator.isNumeric(categoryId, {no_symbols: true})) {
    
    errors+= "invalid category id; ";
    
    }
    
    // Escape text and potentially bad characters
    
    const productName = validator.escape(req.body.productName);
    
    if (productName === "") {
    
    errors+= "invalid productName; ";
    
    }
    
    const productDescription = validator.escape(req.body.productDescription);
    
    if (productDescription === "") {
    
    errors+= "invalid productDescription; ";
    
    }
    
    // Make sure that category id is just a number
    
    const productStock = req.body.productStock;
    
    if (!validator.isNumeric(productStock, {no_symbols: true})) {
    
    errors+= "invalid productStock; ";
    
    }
    
    // Validate currency
    
    const productPrice = req.body.productPrice;
    
    if (!validator.isCurrency(productPrice, {allow_negatives: false})) {
    
    errors+= "invalid productPrice; ";
    
    }
    
    // If errors send details in response
    
    if (errors != "") {
    
    // return http response with errors if validation failed
    
    res.json({ "error": errors });
    
    return false;
    
    }
    
    // If no errors, insert
    
    try {
    
    // Get a DB connection and execute SQL
    
    const pool = await dbConnPoolPromise
    
    const result = await pool.request()
    
    // set name parameter(s) in query
    .input('id', sql.Int, productId)
    .input('categoryId', sql.Int, categoryId)
    .input('productName', sql.NVarChar, productName)
    .input('productDescription', sql.NVarChar, productDescription)
    .input('productStock', sql.Int, productStock)
    .input('productPrice', sql.Decimal, productPrice)
    
    // Execute Query
    
    .query(SQL_UPDATE);
    
    // If successful, return inserted product via HTTP
    
    res.json(result.recordset[0]);
    
    } catch (err) {
    
    res.status(500)
    
    res.send(err.message)
    
    }
    
    });


// now we want to delete a single product from the data
// id is passed as a parameter via url
// address http://server:port/product/id
// returns json
router.delete('/:id', async (req, res) => {

    // read the value of the id parameter from the request url
    const productId = req.params.id;

    // now we want to validate input - important as a bad input could crash the server or lead to an attack
    // if validator fails return an error message
    if(!validator.isNumeric(productId, {no_symbols: true})) {
        res.json({"error": "invalid id parameter"});
        return false;
    }

    // if validation passed ececute the query and return the results
    // returns a single product with the matching id
    try {
        // get a db connection and execute the sql
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // set the name parameter(s) in query
            .input('id', sql.Int, productId)
            // execute query
            .query(SQL_DELETE)

        // send response with JSON result
        res.json(result.recordset)
        
    } catch(err) {
        res.status(500)
        res.send(err.message)
    }
});
    
