// we want to create a function to display the login link if there is no user logged in
// we also want to display the logout link when someone is logged in
function showLoginLink() {
    const link = document.getElementById('loginLink')
  
    // read the session storage values and setting the link
    if (userLoggedIn() === true) {
      link.innerHTML = 'Logout';
      link.removeAttribute('data-toggle');
      link.removeAttribute('data-target');
      link.addEventListener("click", logout);
    }
    else {
      link.innerHTML = 'Login';
      link.setAttribute('data-toggle', 'modal');
      link.setAttribute('data-target', '#LoginDialog');
    }
  
  }
  
  // Login a user
  async function login() {
  
    // Login url
    const url = `${BASE_URL}login/auth` // the api endpoint for the login
  
    // Get form fields
    const email = document.getElementById('email').value; // read the values
    const pwd = document.getElementById('password').value;
    // build request body
    const reqBody = JSON.stringify({ // build the request body
      username: email,
      password: pwd
    });
  
    // Try catch 
    try {
      const json = await postOrPutDataAsync(url, reqBody, 'POST'); // send post request using a function in the fetch.js
      console.log("response: " + json.user);
  
      // A successful login will return a user
      if (json.user === false || json.user === undefined) {
        alert("Invalid Username/Password. Try again.");}
        else{
             // If a user then record in session storage
        sessionStorage.loggedIn = true;
        sessionStorage.setItem('role', json.role);

        console.log(sessionStorage.getItem('role'));
        
        // force reload of page
        location.reload(true);    // if successful set sessionStorage.loggedIn value and reload the page
        }
  
      // catch and log any errors
    } catch (err) {
      console.log(err);
      return err;
    }
  
  }
  
  async function logout() {
  
    // logout url
    const url = `${BASE_URL}login/logout`   //api endpoint
    // Try catch block
    try {
  
      // send request and via fetch                    // send get request using a function in fetch.js
      const json = await getDataAsync(url);
      console.log("response: " + JSON.stringify(json));
  
      // forget user in session storage     //set sessionStorage.loggedIn value and reload the page
      sessionStorage.loggedIn = false;
  
      // force reload of page
      location.reload(true);
  
      // catch and log any errors
      }catch (err) {
        console.log(err);
        return err;
      }
  }

  function userLoggedIn() {

    if (sessionStorage.loggedIn == 'true' ) {
      return true;
    }
    else {
      return false;
    }
  }