// making a displayProducts function for my admin and manager that uses the sessionStorage to confirm to see whos logged in 
// and what theyre allowed to do.
function displayProducts(products) {

    const rows = products.map(product => {

        let row = `<tr>
                <td>${product.ProductId}</td>
                <td>${product.ProductName}</td>
                <td>${product.ProductDescription}</td>
                <td>${product.ProductStock}</td>
                <td class="price">&euro;${Number(product.ProductPrice).toFixed(2)}</td>`
             
        if (userLoggedIn() === true && sessionStorage.getItem('role') === 'admin') {      
            row+= `<td><button class="btn btn-xs" data-toggle="modal" data-target="#ProductFormDialog" onclick="prepareProductUpdate(${product.ProductId})"><span class="oi oi-pencil"></span></button></td>
                   <td><button class="btn btn-xs" onclick="deleteProduct(${product.ProductId})"><span class="oi oi-trash"></span></button></td>`
        }
        if (userLoggedIn() === true && sessionStorage.getItem('role') === 'manager') {      
          row+= `<td><button class="btn btn-xs" data-toggle="modal" data-target="#ProductFormDialog" onclick="prepareProductUpdate(${product.ProductId})"><span class="oi oi-pencil"></span></button></td>`
      }
        row+= '</tr>';

       return row;       
    });
  
    document.getElementById('productRows').innerHTML = rows.join('');
  }
  

  function displayCategories(categories) {

    const items = categories.map(category => {
      return `<a href="#" class="list-group-item list-group-item-action" onclick="updateProductsView(${category.CategoryId})">${category.CategoryName}</a>`;
    });
  
    items.unshift(`<a href="#" class="list-group-item list-group-item-action" onclick="loadProducts()">Show all</a>`);
  
    document.getElementById('categoryList').innerHTML = items.join('');
  } 
  
  
  async function loadProducts() {
    try {
      const categories = await getDataAsync(`${BASE_URL}category`);
      displayCategories(categories);
  
      const products = await getDataAsync(`${BASE_URL}product`);
      displayProducts(products);
  
    } 
    catch (err) {
      console.log(err);
    }
  }
  
  async function updateProductsView(id) {
    try {
      const products = await getDataAsync(`${BASE_URL}product/bycat/${id}`);
      displayProducts(products);

    } 
    catch (err) {
      console.log(err);
    }
  }
  
  async function prepareProductUpdate(id) {

    try {
     
        const product = await getDataAsync(`${BASE_URL}product/${id}`);
        
        document.getElementById('productId').value = product.ProductId; // uses a hidden field - see the form
        document.getElementById('categoryId').value = product.CategoryId;
        document.getElementById('productName').value = product.ProductName;
        document.getElementById('productDescription').value = product.ProductDescription;
        document.getElementById('productStock').value = product.ProductStock;
        document.getElementById('productPrice').value = product.ProductPrice;
    } 
    catch (err) {
    console.log(err);
    }
  }

  async function addOrUpdateProduct() {
  
    let url = `${BASE_URL}product`
  
    const pId = Number(document.getElementById('productId').value);
    const catId = document.getElementById('categoryId').value;
    const pName = document.getElementById('productName').value;
    const pDesc = document.getElementById('productDescription').value;
    const pStock = document.getElementById('productStock').value;
    const pPrice = document.getElementById('productPrice').value;

  
    const reqBody = JSON.stringify({
    categoryId: catId,
    productName: pName,
    productDescription: pDesc,
    productStock: pStock,
    productPrice: pPrice
    });

    
    try {
        let json = "";

        if (pId > 0) {
            url+= `/${pId}`;
            json = await postOrPutDataAsync(url, reqBody, 'PUT');
        }
        else {  
            json = await postOrPutDataAsync(url, reqBody, 'POST');
        }
  
      loadProducts();
     
    } catch (err) {
      console.log(err);
      return err;
    }
  }

  async function deleteProduct(id) {
        
    if (confirm("Are you sure?")) {
        // url
        const url = `${BASE_URL}product/${id}`;
        
        // Try catch 
        try {
            const json = await deleteDataAsync(url);
            console.log("response: " + json);

            loadProducts();

        // catch and log any errors
        } catch (err) {
            console.log(err);
            return err;
        }
    }
  }

 // Show product button to allow the admin to add a product
 function showAddProductButton() {
  let addProductButton= document.getElementById('AddProductButton');    

  if (userLoggedIn() === true && sessionStorage.getItem('role') === 'admin') {
    addProductButton.style.display = 'block';
  }
  else {
    addProductButton.style.display = 'none';
  }
 }

// show login or logout
showLoginLink();

// Load products
loadProducts();

showAddProductButton();