// setting up the connection to the ms sql database and making the connection
// then configuring the package used
// using config to read values from the connection and then exporting the sql and connection objects
let sql = require('mssql');

const config = require('config');

let dbConnPoolPromise = new sql.ConnectionPool(config.get('connection'))
        .connect()
        .then(pool => {
        console.log('Connected to MSSQL DB')
        return pool
        })
        .catch(err => console.log('Database Connection Failed - error: ', err))


module.exports = {
    sql, dbConnPoolPromise
};