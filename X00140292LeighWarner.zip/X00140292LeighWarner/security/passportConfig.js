// Passport Access Control Middlewares
// LocalStrategy: finds username in the DB and verifies password
// JWTStrategy: Extracts JWT from HTTP authorization header (bearer token) and verifies its signature

// Import dependencies
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const passportJWT = require('passport-jwt');
const ExtractJwt = require('passport-jwt').ExtractJwt;
const JWTStrategy = passportJWT.Strategy;
const bcrypt = require('bcryptjs');

// require the databse connection
const { sql, dbConnPoolPromise } = require('../database/db.js');

// config package
const config = require('config');

// we want to read the secret key
const keys = config.get('keys');

// making a function to getUser using async
const getUser = async (username) => {

  try {
        const SQL_FIND_USER = 'SELECT * FROM dbo.AppUser  WHERE Email = @email for json path, without_array_wrapper;';
        
        const pool = await dbConnPoolPromise
        const result = await pool.request()
           
            .input('email', sql.NVarChar, username)
        
            .query(SQL_FIND_USER);

        return (result.recordset[0]);
     
      } catch (err) {
        res.status(500)
        res.send(err.message)
      }
}

// using the middleware as the local strategy
passport.use(new LocalStrategy({
  
  usernameField: 'username',
  passwordField: 'password',
},async (username, password, done) => {
  try {
    const user = await getUser(username);
  
    if (user.Password === password) {
      return done(null, user, { message: 'Logged In Successfully' });
    } else {
      return done(null, false, { message: 'Incorrect Username / Password' });
    }
  } catch (error) {
    done(error);
  }
}));

// jwt strategy middleware
passport.use(new JWTStrategy({

    jwtFromRequest: req => req.cookies.jwt,
    secretOrKey: keys.secret
  },
  (jwtPayload, done) => {
    console.log(`jwt: ${jwtPayload.username}`);
   
    if (parseInt(Date.now()) > parseInt(jwtPayload.expires)) {
      return done('jwt expired');
    } else {
    return done(null, jwtPayload);
    }
  }
));
