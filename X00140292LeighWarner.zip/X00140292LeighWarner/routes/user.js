// here i require express, the json web token, and passport, 
// I use the config package used to manage configuration options, 
// I input the validation package and require the database connection,
// from there i define sql statments i later use in my function below, 
// my first function i was is to use the GET method to get a listing of the users 
// and my second function is to use the GET method again and get a single product 
const router = require('express').Router();

const jwt = require('jsonwebtoken');
const passport = require('passport');

// config package used to manage configuration options
const config = require('config');

const keys = config.get('keys');

// Input validation package
// https://www.npmjs.com/package/validator
const validator = require('validator');

// require the database connection
const { sql, dbConnPoolPromise } = require('../database/db.js');

// defining the sql statements so they can be used in the function below

// for json path - Tell MS SQL to return results as JSON 
const SQL_SELECT_ALL = 'SELECT * FROM dbo.AppUser for json path;';

// for json path, without_array_wrapper - use for single json result
const SQL_SELECT_BY_ID = 'SELECT * FROM dbo.AppUser WHERE UserId = @id for json path, without_array_wrapper;';



// GET listing of all users that will call the jwt middleware in passportConfig.js
router.get('/', passport.authenticate('jwt', { session: false}),
async (req, res) => {

  // Get the db connection
  try {
    const pool = await dbConnPoolPromise
    const result = await pool.request()
      // execute query
      .query(SQL_SELECT_ALL);

    // Send HTTP response.
    // JSON data from MS SQL is contained in first element of the recordset.
    res.json(result.recordset[0]);

    // Catch and send errors  
  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
});

// GET a single product by id
router.get('/:id', passport.authenticate('jwt', { session: false}),
async (req, res) => {

  // read value of id parameter from the request url
  const userId = req.params.id;

  // Validate input, bad input could lead to a leak or an attack
  if (!validator.isNumeric(userId, { no_symbols: true })) {
    res.json({ "error": "invalid id parameter" });
    return false;
  }

  // If validation passed execute query and return results
  // returns a single product with matching id
  try {
    // Get the db connection
    const pool = await dbConnPoolPromise
    const result = await pool.request()
      // set name parameter(s) in query
      .input('id', sql.Int, userId)
      // execute the query
      .query(SQL_SELECT_BY_ID);

    // Send response with JSON result    
    res.json(result.recordset)

  } catch (err) {
    res.status(500)
    res.send(err.message)
  }
});

module.exports = router;
