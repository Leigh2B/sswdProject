const router = require('express').Router();

// validating the package
const validator = require('validator');

// require the database connection
const { sql, dbConnPoolPromise } = require('../database/db.js');

const SQL_SELECT_ALL = 'SELECT * FROM dbo.Category ORDER BY CategoryName ASC for json path;';

const SQL_SELECT_BY_ID = 'SELECT * FROM dbo.Category WHERE CategoryId = @id for json path, without_array_wrapper;';

// using the GET method to get a listing of all the categories
router.get('/', async (req, res) => {

    // Get a DB connection
    try {
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // execute the query
            .query(SQL_SELECT_ALL);
        
        // Send HTTP response.
        
        res.json(result.recordset[0]);

      // Catch and send errors  
      } catch (err) {
        res.status(500)
        res.send(err.message)
      }
});

// GET a single product by id and pass the id in the parameters
router.get('/:id', async (req, res) => {

    // read value of id parameter from the request url
    const categoryId = req.params.id;

    // we want to validate the input to avoid a leak or attacks
    if (!validator.isNumeric(categoryId, { no_symbols: true })) {
        res.json({ "error": "invalid id parameter" });
        return false;
    }

    // If validation passed execute query and return results
    // returns a single product with matching id
    try {
        // Get the DB connection
        const pool = await dbConnPoolPromise
        const result = await pool.request()
            // set name parameter in query
            .input('id', sql.Int, categoryId)
            // execute query
            .query(SQL_SELECT_BY_ID);

        // Send response with JSON result    
        res.json(result.recordset)

        } catch (err) {
            res.status(500)
            res.send(err.message)
        }
});
// export the router
module.exports = router;
